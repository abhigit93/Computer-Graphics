//langrange curve points
#define lcurve1 20
#define lcurve2 3
#define lcurve3 5
#define lcurve4 3
//bezier curve points
#define bcurve1 8
#define bcurve2 11
#define bcurve3 9
#define bcurve4 7
#define bcurve5 11

