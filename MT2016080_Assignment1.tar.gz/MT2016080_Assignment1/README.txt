SOURCES REFERRED:

1)The Official Guide to learning OpenGL(Red Book)
2)https://www.opengl.org/
3)http://users.polytech.unice.fr/~buffa/cours/synthese_image/DOCS/www.xmission.com/Nate/tutors.html
4)http://elvenware.sourceforge.net/OpenGLNotes.html#Ortho
5)https://www.it.uu.se/edu/course/homepage/grafik1/ht07/examples/curves.cpp



INSTRUCTIONS:

Compiling and running application.

Run the following commands on terminal.
a)make -f Makefile
b)cd bin
c)./Run
After running the application
d)cd ..
e)make clean


INPUT-OUTPUTS
A window with both the curves will open.
        Use key 'r'-rotate right.
        Use key 'l'-rorate left.
        Use key '+'-Zoom in.
        Use key '-'-Zoom out.
        
For the translation:
        Mouse left click-Points selection.
Here first click will select a point,second click will select another point and image will be translated accordingly.

For Deleting Points:
        Use key 'b'-Bezier curve will appear.
        Use key 'd'-Lagrange curve will appear.
In both the modes select any point by Mouse Right Click and the curve will be redrawn.



DEFECTS AND EFFECTS

1)Sometimes Lagrange curve behaves vaguely after deleting a point.
2)Delete modes(Use key 'b' and 'd') are only for the purpose of deleting a point and redrawing.
3)While using keys 'l','r', '+','-' the application will automatically show the initial window(with both curves) where it was left(by shifting to delete operations).


         
         

